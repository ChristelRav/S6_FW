
public class bdd{
    int id_bdd; 
 String bdd; 
 String driver; 
  
     public int getid_bdd(){
        return id_bdd;
    }

    public void setid_bdd(int id_bdd) {
        this.id_bdd = id_bdd;
    }

     public String getbdd(){
        return bdd;
    }

    public void setbdd(String bdd) {
        this.bdd = bdd;
    }

     public String getdriver(){
        return driver;
    }

    public void setdriver(String driver) {
        this.driver = driver;
    }

 #getset 
 
 

}
