public class BVResult {
    int code;
    String region;
    String district;
    String commune;
    String fokontany;
    String centredevote;
    String bureaudevote;
    
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getCommune() {
		return commune;
	}
	public void setCommune(String commune) {
		this.commune = commune;
	}
	public String getFokontany() {
		return fokontany;
	}
	public void setFokontany(String fokontany) {
		this.fokontany = fokontany;
	}
	public String getCentredevote() {
		return centredevote;
	}
	public void setCentredevote(String centredevote) {
		this.centredevote = centredevote;
	}
	public String getBureaudevote() {
		return bureaudevote;
	}
	public void setBureaudevote(String bureaudevote) {
		this.bureaudevote = bureaudevote;
	}
    
}
