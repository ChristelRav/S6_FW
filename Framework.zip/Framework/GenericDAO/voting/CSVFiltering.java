import org.apache.commons.csv.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

// java -cp "D:\S5\Framework\GenericDAO\lib\commons-csv-1.10.0.jar:." CSVFiltering

public class CSVFiltering {
    public static void main(String[] args) {
        String folderPath = "D:\\S5\\Archi log\\Voting\\S5 fifidianana";
        String csvFilePath = "D:\\S5\\Archi log\\Voting\\Copie de liste-bv.csv";
        String filteredCsvFilePath = "D:\\S5\\Archi log\\Voting\\filtered_csv.csv";

        List<String> fileCodes = getFileCodes(folderPath);
        filterCSV(csvFilePath, filteredCsvFilePath, fileCodes);
    }

    // Method to get BV codes from filenames in the folder
    private static List<String> getFileCodes(String folderPath) {
        List<String> fileCodes = new ArrayList<>();
        File folder = new File(folderPath);

        if (folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    String fileName = file.getName();
                    if (fileName.endsWith(".txt")) {
                        String code = fileName.replace(".pdf.txt", "");
                        fileCodes.add(code);
                    }
                }
            }
        }

        return fileCodes;
    }

    // Method to filter CSV based on BV codes
    private static void filterCSV(String csvFilePath, String filteredCsvFilePath, List<String> fileCodes) {
        try (Reader reader = new FileReader(csvFilePath);
             Writer writer = new FileWriter(filteredCsvFilePath);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {

            CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("N", "REGION", "DISTRICT", "COMMUNE", "FOKONTANY", "CENTRE DE VOTE", "CODE BV", "BUREAU DE VOTE"));

            for (CSVRecord record : csvParser) {
                String codeBV = record.get("CODE BV");
                if (fileCodes.contains(codeBV)) {
                    csvPrinter.printRecord(record);
                }
            }
            csvPrinter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
