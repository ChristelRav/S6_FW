import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BVConstructor {
    public static void main(String[] args) {
        try {
            String fileContent = readFileAsString("D:\\S5\\Archi log\\Voting\\S5 fifidianana\\110101010101.pdf.txt");
            // System.out.println("File Content:");
            // System.out.println(fileContent);
    
            HashMap<String, String> extractedInfo = extractData(fileContent);
    
            // Display extracted information
            for (String key : extractedInfo.keySet()) {
                System.out.println(key + ": " + extractedInfo.get(key));
            }
            List<String> candidateData = extractCandidates(fileContent);
    
            // Display modified candidate data
            // for (String data : candidateData) {
            //     System.out.println(data);
            // }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Assuming you already have fileContent from reading the file
    }

    //get candidat result
    public static List<String> extractCandidates(String input) {
        List<String> extractedCandidates = new ArrayList<>();

        // Define a pattern to match candidate lines
        Pattern pattern = Pattern.compile("\\b\\w+\\d+\\s\\d+\\.\\d+%");
        Matcher matcher = pattern.matcher(input);

        // Find and extract candidate lines
        while (matcher.find()) {
            String candidateInfo = matcher.group();
            extractedCandidates.add(candidateInfo);
        }

        return extractedCandidates;
    }

    //get file as string
    public static String readFileAsString(String filePath) throws IOException {
        StringBuilder content = new StringBuilder();
        
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line).append("\n"); // Append each line with a newline character
            }
        }
        
        return content.toString();
    }

    //extract metadata
    public static HashMap<String, String> extractData(String fileContent) {
        HashMap<String, String> extractedData = new HashMap<>();

        String[] lines = fileContent.split("\\r?\\n");

        for (String line : lines) {
            if(line.startsWith("Région:")){
                extractedData.put("Région:", line.substring("Région: ".length()));
            } else if (line.startsWith("District:")) {
                extractedData.put("District", line.substring("District:".length()));
            } else if (line.startsWith("Commune:")) {
                extractedData.put("Commune", line.substring("Commune: ".length()));
            } else if (line.startsWith("Fokontany:")) {
                extractedData.put("Fokontany", line.substring("Fokontany: ".length()));
            } else if (line.startsWith("Centre de Vote:")) {
                extractedData.put("Centre de Vote", line.substring("Centre de Vote: ".length()));
            } else if (line.startsWith("Bureau de Vote :")) {
                extractedData.put("Bureau de Vote", line.substring("Bureau de Vote :".length()));
            } else if (line.startsWith("Inscrits:")) {
                extractedData.put("Inscrits", line.substring("Inscrits: ".length()));
            } else if (line.startsWith("Votants:")) {
                extractedData.put("Votants", line.substring("Votants: ".length()));
            } else if (line.startsWith("Blancs:")) {
                extractedData.put("Blancs", line.substring("Blancs: ".length()));
            } else if (line.startsWith("Suffrages exprimés:")) {
                extractedData.put("Suffrages exprimés", line.substring("Suffrages exprimés: ".length()));
            }
        }

        return extractedData;
    }
}
