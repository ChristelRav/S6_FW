package DOA;
import java.sql.Statement;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ClassGenerator {

    public static void main(String[] args) {
        String connectionString = "jdbc:postgresql://localhost:5432/language_syntax";
        String username = "postgres";
        String password = "postgres";
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Class Generator CLI!");

        System.out.print("Enter connection string (if applicable): ");
        String connectionString = scanner.nextLine();

        System.out.print("Enter table name (if applicable): ");
        String tableName = scanner.nextLine();

        System.out.print("Enter language (Java or C#): ");
        String language = scanner.nextLine();

        System.out.print("Enter directory path: ");
        String directoryPath = scanner.nextLine();

        System.out.print("Enter class name: ");
        String className = scanner.nextLine();

        System.out.print("Enter package/namespace name: ");
        String packageName = scanner.nextLine();

        // Now you have collected user inputs
        // Pass these inputs to your class generation logic
        // For instance, call a method to generate the class
        generateClass(connectionString, tableName, language, directoryPath, className, packageName);

        scanner.close();
    }

    private static Connection getConnection(String connectionString,String user,String password) throws SQLException {
        return DriverManager.getConnection(connectionString,user,password);
    }

    private static String readTemplateFile(String filePath) {
        StringBuilder contentBuilder = new StringBuilder();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line = "";
            while ((line = br.readLine()) != null) {
                contentBuilder.append(line).append("\n"); // Append each line and add newline character
            }
        } catch (IOException e) {
            System.out.println("Error reading the template file: " + e.getMessage());
        }

        return contentBuilder.toString();
    }
    private static String retrieveSyntax(String language, String syntaxType, Connection connection) {
        String syntax = ""; // Placeholder for retrieved syntax information

        try {
            String query = "SELECT data FROM language_syntax WHERE techno = ? AND syntax_type = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, language);
            preparedStatement.setString(2, syntaxType);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                syntax = resultSet.getString("data");
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving syntax information: " + e.getMessage());
        }

        return syntax;
    }

    private static String processTemplate(String language,String connectionString,
    String user,String password,
    String tableName,String template, String packageName,String className) {
        // connection syntax
        try (Connection connection = getConnection("jdbc:postgresql://localhost:5432/language_syntax",
        "postgres","postgres")) {
            String query = "SELECT data FROM language_syntax WHERE techno = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, language);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                syntax = resultSet.getString("data");
            }

            // Return processed content
            return "Processed content";
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
            return "";
        }
    }

    private static void generateClass(String connectionString, String tableName, String language,
                                      String directoryPath, String className, String packageName) {
        String templateContent = readTemplateFile(language); // Read the appropriate template based on language

        // Replace placeholders in the template with user-provided values
        String processedContent = processTemplate(language,connectionString,tableName,templateContent, packageName, className);

        // Generate class file
        String fileExtension = getFileExtension(language);
        String filePath = directoryPath + "/" + className + fileExtension;

        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
            writer.println(processedContent);
            System.out.println("Generated " + className + fileExtension + " successfully!");
        } catch (IOException e) {
            System.out.println("Error creating file: " + e.getMessage());
        }
    }
}
