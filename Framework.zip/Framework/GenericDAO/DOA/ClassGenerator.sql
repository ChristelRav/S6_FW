CREATE TABLE language_syntax (
    id SERIAL PRIMARY KEY,
    techno VARCHAR(50) NOT NULL,
    data text NOT NULL
);

-- Insert syntax data for Java
INSERT INTO language_syntax (techno, data)
VALUES 
('JAVA', '{"pkg": "package", "import":"import","classStart": "class", "fieldDeclaration": "private", "methodDeclaration": "public"}');

-- Insert syntax data for C#
INSERT INTO language_syntax (techno, data)
VALUES 
('C#', '{"pkg": "namespace", "import":"using","classStart": "class", "fieldDeclaration": "private", "methodDeclaration": "public"}');
