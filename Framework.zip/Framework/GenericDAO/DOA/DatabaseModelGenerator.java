package DOA;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class DatabaseModelGenerator {

    private Connection connection;
    private String table;

    public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public DatabaseModelGenerator(Connection con,String table){
        this.setConnection(con);
        this.setTable(table);
    }

    public DatabaseModelGenerator(){}    
    public void generateModel() {
        try {
            DatabaseMetaData metaData = this.getConnection().getMetaData();

            // Retrieve table information
            // ResultSet tables = metaData.getTables(null, null, "%", new String[] { "TABLE" });
            
            generateModelForTable(metaData, this.getTable());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void generateModelForTable(DatabaseMetaData metaData, String tableName) throws Exception {
        ResultSet columns = metaData.getColumns(null, null, tableName, null);

        System.out.println("import java.util.*;");
        System.out.println("import java.sql.*;");
        System.out.println();

        Set<String> imports = new HashSet<>();

        System.out.println("public class " + DatabaseModelGenerator.ucfirst(tableName) + " {");

        while (columns.next()) {
            String columnName = columns.getString("COLUMN_NAME");
            String columnType = columns.getString("TYPE_NAME");

            // You can customize the generation of the model here
            String attributeType = mapColumnType(columnType);
            System.out.println("\tprivate " + attributeType + " " + columnName + ";");

            // Determine imports based on attribute types
            String importStmt = generateImportStatement(attributeType);
            if (importStmt != null) {
                imports.add(importStmt);
            }
        }

        // Output required imports
        for (String importStmt : imports) {
            System.out.println(importStmt);
        }

        System.out.println("}");
    }

    // Map database column types to Java types (you can extend this as needed)
    private String mapColumnType(String columnType) {
        switch (columnType.toLowerCase()) {
            // Numeric Types
            case "int2":
            case "int4":
            case "int8":
            case "smallint":
            case "integer":
            case "bigint":
                return "int";
            // Text Types
            case "varchar":
            case "text":
            case "char":
            case "character varying":
                return "String";
            // Boolean Type
            case "boolean":
                return "boolean";
            // Floating-Point Types
            case "real":
            case "float4":
                return "float";
            case "float8":
            case "double precision":
                return "double";
            // Numeric Types with Precision
            case "numeric":
                return "BigDecimal";
            // Date/Time Types
            case "date":
                return "java.sql.Date";
            case "time":
            case "time without time zone":
            case "time with time zone":
                return "java.sql.Time";
            case "timestamp":
            case "timestamp without time zone":
            case "timestamp with time zone":
                return "java.sql.Timestamp";
            // Add more cases for other data types as needed
            default:
                return "Object";
        }
    }
    
    private String generateImportStatement(String attributeType) {
        switch (attributeType) {
            case "BigDecimal":
                return "import java.math.BigDecimal;";
            case "Timestamp":
                return "import java.sql.Timestamp;";
            case "Date":
                return "import java.sql.Date;";
            case "Time":
                return "import java.sql.Time;";
            // Add more cases for other types as needed
            default:
                return null; // No specific import needed for this type
        }
    }

    public static String ucfirst(String input)throws Exception{
        if (!input.isEmpty()) {
            return input.substring(0, 1).toUpperCase() + input.substring(1);
        } else {
            throw new Exception("String is empty");
        }
    }
}

