package DOA;

import PGSQLConnection;

public class DAO{
    public static void main(String[] args) {
        try {
            DatabaseModelGenerator generator = new DatabaseModelGenerator(PGSQLConnection.getConnection(),"xmodel");
            generator.generateModel();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}